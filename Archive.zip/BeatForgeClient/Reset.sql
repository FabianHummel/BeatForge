DELETE FROM main.c_channel WHERE TRUE;
DELETE FROM main.i_instrument WHERE TRUE;
DELETE FROM main.n_note WHERE TRUE;
DELETE FROM main.p_preferences WHERE TRUE;
DELETE FROM main.s_song WHERE TRUE;