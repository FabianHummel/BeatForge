﻿using ReactiveUI;

namespace BeatForgeClient.ViewModels;

public class ViewModelBase : ReactiveObject { }