﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BeatForgeClient.Migrations
{
    public partial class UpdatedChannel : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<double>(
                name: "Volume",
                table: "c_channel",
                type: "REAL",
                nullable: false,
                defaultValue: 0.0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Volume",
                table: "c_channel");
        }
    }
}
