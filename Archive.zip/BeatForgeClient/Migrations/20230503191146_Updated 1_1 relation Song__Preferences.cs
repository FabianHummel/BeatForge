﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BeatForgeClient.Migrations
{
    public partial class Updated11relationSongPreferences : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_p_preferences_SongId",
                table: "p_preferences");

            migrationBuilder.CreateIndex(
                name: "IX_p_preferences_SongId",
                table: "p_preferences",
                column: "SongId",
                unique: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_p_preferences_SongId",
                table: "p_preferences");

            migrationBuilder.CreateIndex(
                name: "IX_p_preferences_SongId",
                table: "p_preferences",
                column: "SongId");
        }
    }
}
