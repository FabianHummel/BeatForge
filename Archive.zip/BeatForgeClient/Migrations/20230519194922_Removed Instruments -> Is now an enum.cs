﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BeatForgeClient.Migrations
{
    public partial class RemovedInstrumentsIsnowanenum : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "i_instrument");

            migrationBuilder.AddColumn<int>(
                name: "Instrument",
                table: "c_channel",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Instrument",
                table: "c_channel");

            migrationBuilder.CreateTable(
                name: "i_instrument",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    ChannelId = table.Column<int>(type: "INTEGER", nullable: false),
                    Name = table.Column<string>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_i_instrument", x => x.Id);
                    table.ForeignKey(
                        name: "FK_i_instrument_c_channel_ChannelId",
                        column: x => x.ChannelId,
                        principalTable: "c_channel",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_i_instrument_ChannelId",
                table: "i_instrument",
                column: "ChannelId",
                unique: true);
        }
    }
}
