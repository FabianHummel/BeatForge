﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BeatForgeClient.Migrations
{
    public partial class UpdatedSongPreferences : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Length",
                table: "s_song");

            migrationBuilder.AddColumn<int>(
                name: "Bpm",
                table: "p_preferences",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Length",
                table: "p_preferences",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Bpm",
                table: "p_preferences");

            migrationBuilder.DropColumn(
                name: "Length",
                table: "p_preferences");

            migrationBuilder.AddColumn<int>(
                name: "Length",
                table: "s_song",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);
        }
    }
}
