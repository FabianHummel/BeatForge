using Avalonia;
using Avalonia.Controls;
using Avalonia.Markup.Xaml;
using BeatForgeClient.Infrastructure;
using BeatForgeClient.ViewModels;

namespace BeatForgeClient.Views;

public partial class Titlebar : UserControl
{
    public Titlebar()
    {
        InitializeComponent();
    }
}