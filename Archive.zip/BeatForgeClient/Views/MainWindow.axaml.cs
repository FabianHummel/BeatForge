using Avalonia.Controls;

namespace BeatForgeClient.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}